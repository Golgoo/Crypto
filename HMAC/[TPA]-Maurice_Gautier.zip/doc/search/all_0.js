var searchData=
[
  ['addheader',['addHeader',['../class_mailer.html#a6647889f6d2214e49aca064347904d5d',1,'Mailer']]]
];
